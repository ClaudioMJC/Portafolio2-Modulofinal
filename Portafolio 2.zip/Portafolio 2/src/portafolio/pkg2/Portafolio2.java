/*
 Claudio Jiménez Castro
03/09/2023
 */
package portafolio.pkg2;
import java.util.Scanner;

/**
 *
 * @author Claudio
 */
public class Portafolio2 {

      private static int[][] matriz; // Declarar la matriz como una variable de clase.
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        matriz = new int[6][5];
        int opcion;
        do {  
            mostrarMenu();
            opcion=leerOpcion(scanner);
            ejecutarOpcion(opcion, scanner);
            
        } while (opcion !=5);// Continuar hasta que el usuario elija salir (opción 5).
        System.out.println("¡Hasta luego!");
    }
    
     // Método para mostrar el menú y solicitar la opción al usuario, según la opción se ejecutan ciertas instrucciones.
    public static void mostrarMenu() {
        System.out.println("Menú:");
        System.out.println("1 - Número Factorial.");
        System.out.println("2 - Los 10 primeros números Primos.");
        System.out.println("3 - Crear una matriz de números al azar.");
        System.out.println("4 - Obtener el número mayor de la matriz.");
        System.out.println("5 - Salir.");
        System.out.print("Seleccione una opción: ");
    }
    
      // Método para leer la opción del usuario y verificar si es válida.
    public static int leerOpcion(Scanner scanner) {
        int opcion;
        do {    //se ejecuta el ciclo al menos una vez mientras la opción no este dentro del rango de 1 a 5
            while (!scanner.hasNextInt()) {   //se verifica si lo que el usuario ingresó no es un número entero
                                              
                scanner.next(); // Limpiar el búfer en caso de entrada no válida.
                System.out.print("Por favor, ingrese un número válido: ");
            }
            opcion = scanner.nextInt();
        } while (opcion < 1 || opcion > 5); // Verificar que la opción esté en el rango válido.
        return opcion;
    }
    
    
    // Método para ejecutar la opción seleccionada por el usuario.
    public static void ejecutarOpcion(int opcion, Scanner scanner) {
        switch (opcion) {
            case 1:
                calcularFactorial(scanner);
                break;
            case 2:
                obtenerPrimerosPrimos();
                break;
            case 3:
                crearYMostrarMatriz();
                break;
            case 4:
                obtenerMayorDeMatriz(matriz);
                break;
            case 5:
                // Salir: No se requiere ninguna acción adicional aquí.
                break;
        }
    }
    
    
      // calcula el factorial de un número ingresado por el usuario.
    public static void calcularFactorial(Scanner scanner) {  //recibe scanner como parámetro para leer la opción
        System.out.print("Ingrese un número entero: ");
        int numero = scanner.nextInt();  //lee la opción y la asigna a la variable numero
        long factorial = 1;  //el factorial comienza en valor 1, ya que el factorial de cero y uno es 1
        //la variable se define de tipo long, ya que esta permite almacenar valores muy grandes dependiendo del número que se esté      calculando
        for (int i = 2; i <= numero; i++) {  //bucle que calcula el factorial, multiplicando este por los enteros que hayan desde el 1
            factorial *= i;                  //hasta el número que el usuario desea calcular el factorial
        }
        System.out.println("El factorial de " + numero + " es " + factorial); //muestra el resultado
    }
    
    
    // Método para obtener los primeros 10 números primos y mostrarlos.
public static void obtenerPrimerosPrimos() {
    int[] numerosPrimos = new int[10]; // Creamos un arreglo para almacenar los primeros 10 números primos.
    int contador = 0; // Inicializamos un contador para llevar un registro de cuántos números primos hemos encontrado.
    int numero = 2; // Comenzamos con el primer número primo, que es 2.

    while (contador < 10) { // Mientras no hayamos encontrado los 10 números primos que buscamos...
        if (esPrimo(numero)) { // Verificamos si 'numero' es un número primo utilizando el método 'esPrimo'.
            numerosPrimos[contador] = numero; // Si es primo, lo almacenamos en el arreglo 'numerosPrimos'.
            contador++; // Incrementamos el contador de números primos encontrados.
        }
        numero++; // Pasamos al siguiente número para continuar la búsqueda.
    }

    System.out.println("Los primeros 10 números primos son:");
    for (int primo : numerosPrimos) {
        System.out.print(primo + " "); // Mostramos los números primos encontrados.
    }
    System.out.println();
}

// Método para verificar si un número es primo.
public static boolean esPrimo(int numero) {
    if (numero <= 1) {
        return false; // Si el número es menor o igual a 1, no es primo.
    }
    for (int i = 2; i * i <= numero; i++) {  // i*i se le conoce como  "optimización de raíz cuadrada"
                                             //reduce la cantidad de cálculos innecesarios para determinar si un número es primo o no
        if (numero % i == 0) {               //ejemplo: el número 36, se tendría que hacer 34 verificaciones desde el 2 al 35, con la forma
            return false; // Si 'numero' es divisible por 'i', no es primo.  //optimizada solo se verifica del 2 hasta la raíz de 36, osea 6
        }
    }
    return true; // Si no encontramos divisores, 'numero' es primo.
}



 // Método para crear y mostrar una matriz de números al azar.
    public static void crearYMostrarMatriz() {
        //int[][] matriz1 = new int[6][5];

        for (int fila = 0; fila < 6; fila++) {     //se crea la matriz con las 5 filas y 6 columnas
            for (int columna = 0; columna < 5; columna++) {
                matriz[fila][columna] = (int) (Math.random() * 200) + 1;  //se llenan con los números enteros aleatorios del 1 al 200
            }
        }

        System.out.println("Matriz");
        for (int fila = 0; fila < 6; fila++) {
            for (int columna = 0; columna < 5; columna++) {
                System.out.printf("%4d ", matriz[fila][columna]); //%4d formato que ayuda a ordenar los números en las columnas
            }                                                           //se muestran alineados
            System.out.println();
        }
    }
    
    
    // Método para obtener el número mayor de la matriz.
    public static void obtenerMayorDeMatriz(int[][] matriz) {
    if (matriz == null || matriz.length == 0 || matriz[0].length == 0) {
        System.out.println("La matriz no está inicializada o es de tamaño incorrecto.");
        return;
    }

    int mayor = matriz[0][0]; // Suponemos que el primer elemento es el mayor.
        for (int[] matriz1 : matriz) {
            for (int columna = 0; columna < matriz[0].length; columna++) {
                if (matriz1[columna] > mayor) {
                    mayor = matriz1[columna];  //se va iterando y si se encuentra un
                                             //un valor mayor se actualiza "mayor""
                                             //y se asigna el nuevo valor mayor a la variable
                }                         //una vez recorrida toda la matriz se devuelve el valor más alto
            }
        }

    System.out.println("El número mayor en la matriz es: " + mayor);
}


    
}
